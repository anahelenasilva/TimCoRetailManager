﻿namespace TRMDesktopUI.Library.Helpers
{
    public interface IConfigHelper
    {
        decimal GetTaxRate();
    }
}